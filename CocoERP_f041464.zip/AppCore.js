/** =========================================================
 * AppCore.gs – Core Config & Helpers for CocoERP v2.2+
 * "System Kernel" version (stable + extensible)
 * =========================================================
 * Goals:
 *  - Single source of truth for Sheet names + Column headers
 *  - Schema validation + optional repair
 *  - Settings abstraction (FX/Shipping/Customs/etc.)
 *  - Safe triggers + locking + centralized error logging
 *
 * Notes:
 *  - This file owns the ONLY global onOpen(e) and onEdit(e).
 *  - Other modules must NOT define onOpen/onEdit.
 * ========================================================= */

/** ===================== GLOBAL CONFIG ===================== */
const APP = {
  VERSION: '2.2.1',

  BASE: {
    SPREADSHEET_ID: '1CVRbQbQrERmKSFg3jUi6xqLwJjZ4XsjUbhuMDIahCFk',
    TIMEZONE: Session.getScriptTimeZone() || 'Africa/Cairo'
  },


  // Warehouses (canonical codes + legacy aliases)
  // Canonical now used in Sheets:
  //  - UAE: KOR, ATTIA
  //  - EG : TAN-GH
  // Legacy aliases are kept for backward compatibility (older data / older modules).
  WAREHOUSES: {
    // Canonical
    KOR: 'KOR',
    ATTIA: 'ATTIA',
    TAN_GH: 'TAN-GH',

    // Legacy (kept)
    UAE_DXB: 'UAE-DXB',
    UAE_ATTIA: 'UAE-ATTIA',
    UAE_KOR: 'UAE-KOR',
    EG_CAI: 'EG-CAI',
    EG_TANTA: 'EG-TANTA'
  },

  WAREHOUSE_GROUPS: {
    UAE: ['KOR', 'ATTIA', 'UAE-DXB', 'UAE-ATTIA', 'UAE-KOR'],
    EG: ['TAN-GH', 'EG-CAI', 'EG-TANTA']
  },

  SHEETS: {
    // Core
    PURCHASES: 'Purchases',
    SETTINGS: 'Settings',
    ORDERS: 'Orders',

    // Logistics
    QC_UAE: 'QC_UAE',
    SHIP_CN_UAE: 'Shipments_CN_UAE',
    SHIP_UAE_EG: 'Shipments_UAE_EG',

    // Inventory
    INVENTORY_TXNS: 'Inventory_Transactions',
    INVENTORY_UAE: 'Inventory_UAE',
    INVENTORY_EG: 'Inventory_EG',
    CATALOG_EG: 'Catalog_EG',
    SKU_RATES: 'SKU_Rates',

    // Sales
    SALES_EG: 'Sales_EG',

    // System
    ERROR_LOG: 'ErrorLog',
    DASHBOARD: 'Dashboard'
  },

  /**
   * Canonical column headers (single source of truth).
   * IMPORTANT: Headers are the actual sheet header strings.
   */
  COLS: {
    PURCHASES: {
      ORDER_ID: 'Order ID',
      ORDER_DATE: 'Order Date',
      PLATFORM: 'Platform',
      SELLER: 'Seller Name',
      SKU: 'SKU',

      // Canonical:
      PRODUCT_NAME: 'Product Name',
      VARIANT: 'Variant / Color',

      // Backward-compat aliases (do NOT use in new code):
      PRODUCT: 'Product Name',       // legacy alias
      VARIANT_CLR: 'Variant / Color',    // legacy alias

      BATCH_CODE: 'Batch Code',
      LINE_ID: 'Line ID',
      QTY: 'Qty',
      TOTAL_ORIG: 'Total Order (Orig)',
      TOTAL_EGP: 'Order Total (EGP)',
      LANDED_COST: 'Landed Cost (EGP)',
      UNIT_LANDED: 'Unit Landed Cost (EGP)',
      NET_UNIT_PRICE: 'Net Unit Price (EGP)',
      CURRENCY: 'Currency',
      BUYER_NAME: 'Buyer Name',
      SHIP_EG: 'Ship UAE→EG (EGP)',
      CUSTOMS_EGP: 'Customs/Fees (EGP)',
      NOTES: 'Notes'
    },

    ORDERS: {
      ORDER_ID: 'Order ID',
      TOTAL_LINES: 'Total Lines',
      TOTAL_QTY: 'Total Qty',
      TOTAL_ORIG: 'Total Order (Orig)',
      TOTAL_EGP: 'Order Total (EGP)',
      SHIP_EG: 'Ship UAE→EG (EGP)',
      CUSTOMS: 'Customs/Fees (EGP)',
      LANDED_COST: 'Landed Cost (EGP)',
      PROFIT_EGP: 'Profit (EGP)',
      UNIT_LANDED: 'Unit Landed Cost (EGP)'
    },

    QC_UAE: {
      QC_ID: 'QC ID',
      ORDER_ID: 'Order ID',
      SHIPMENT_ID: 'Shipment CN→UAE ID',
      SKU: 'SKU',
      BATCH_CODE: 'Batch Code',
      PRODUCT_NAME: 'Product Name',
      VARIANT: 'Variant / Color',
      QTY_ORDERED: 'Qty Ordered',
      QTY_RECEIVED: 'Qty Received',
      QTY_OK: 'Qty OK',
      QTY_MISSING: 'Qty Missing',
      QTY_DEFECT: 'Qty Defective',
      QC_RESULT: 'QC Result',
      QC_DATE: 'QC Date',
      WAREHOUSE: 'Warehouse (UAE)',
      PURCHASE_LINE_ID: 'Purchases Line ID',
      NOTES: 'Notes'
    },

    SHIP_CN_UAE: {
      SHIPMENT_ID: 'Shipment ID',
      SUPPLIER: 'Supplier / Factory',
      FORWARDER: 'Forwarder',
      TRACKING: 'Tracking / Container',
      ORDER_BATCH: 'Order ID (Batch)',
      SHIP_DATE: 'Ship Date',
      ETA: 'ETA',
      ARRIVAL: 'Actual Arrival',
      STATUS: 'Status',
      WAREHOUSE_UAE: 'Warehouse (UAE)',
      SKU: 'SKU',
      PRODUCT_NAME: 'Product Name',
      VARIANT: 'Variant / Color',
      QTY: 'Qty',
      WEIGHT: 'Gross Weight (kg)',
      VOLUME: 'Volume (CBM)',
      FREIGHT_AED: 'Freight (AED)',
      OTHER_AED: 'Other Fees (AED)',
      TOTAL_AED: 'Total Cost (AED)',
      PURCHASE_LINE_ID: 'Purchases Line ID',
      NOTES: 'Notes'
    },

    SHIP_UAE_EG: {
      SHIPMENT_ID: 'Shipment ID',
      FORWARDER: 'Forwarder',
      COURIER: 'Courier',
      AWB: 'AWB / Tracking',
      BOX_ID: 'Box ID',
      SHIP_DATE: 'Ship Date',
      ETA: 'ETA',
      ARRIVAL: 'Actual Arrival',
      STATUS: 'Status',
      SKU: 'SKU',
      PRODUCT_NAME: 'Product Name',
      VARIANT: 'Variant / Color',
      QTY: 'Qty',
      QTY_SYNCED: 'Qty Synced',
      SHIP_COST: 'Ship Cost (EGP) – per unit or box',
      CUSTOMS: 'Customs (EGP)',
      OTHER: 'Other (EGP)',
      TOTAL_COST: 'Total Cost (EGP)',
      NOTES: 'Notes'
    },

    INV_TXNS: {
      TXN_ID: 'Txn ID',
      TXN_DATE: 'Txn Date',
      SOURCE_TYPE: 'Source Type',
      SOURCE_ID: 'Source ID',
      BATCH_CODE: 'Batch Code',
      SKU: 'SKU',
      PRODUCT_NAME: 'Product Name',
      VARIANT: 'Variant / Color',
      WAREHOUSE: 'Warehouse',
      QTY_IN: 'Qty In',
      QTY_OUT: 'Qty Out',
      UNIT_COST: 'Unit Cost (EGP)',
      TOTAL_COST: 'Total Cost (EGP)',
      CURRENCY: 'Currency',
      UNIT_PRICE_ORIG: 'Unit Price (Orig)',
      NOTES: 'Notes'
    },

    INV_UAE: {
      SKU: 'SKU',
      PRODUCT_NAME: 'Product Name',
      VARIANT: 'Variant / Color',
      WAREHOUSE: 'Warehouse (UAE)',
      ON_HAND: 'On Hand Qty',
      ALLOCATED: 'Allocated Qty',
      AVAILABLE: 'Available Qty',
      AVG_COST: 'Avg Cost (EGP)',
      TOTAL_COST: 'Total Cost (EGP)',
      LAST_TXN: 'Last Txn Date',
      LAST_SRC_TYPE: 'Last Source Type',
      LAST_SRC_ID: 'Last Source ID'
    },

    INV_EG: {
      SKU: 'SKU',
      PRODUCT_NAME: 'Product Name',
      VARIANT: 'Variant / Color',
      WAREHOUSE: 'Warehouse (EG)',
      ON_HAND: 'On Hand Qty',
      ALLOCATED: 'Allocated Qty',
      AVAILABLE: 'Available Qty',
      AVG_COST: 'Avg Cost (EGP)',
      TOTAL_COST: 'Total Cost (EGP)',
      LAST_TXN: 'Last Txn Date',
      LAST_SRC_TYPE: 'Last Source Type',
      LAST_SRC_ID: 'Last Source ID'
    },

    CATALOG_EG: {
      SKU: 'SKU',
      PRODUCT_NAME: 'Product Name',
      VARIANT: 'Variant / Color',
      COLOR_GROUP: 'Color Group',
      BRAND: 'Brand',
      CATEGORY: 'Category',
      SUBCATEGORY: 'Subcategory',
      STATUS: 'Status',
      DEFAULT_COST: 'Default Cost (EGP)',
      DEFAULT_PRICE: 'Default Price (EGP)',
      BARCODE: 'Barcode',
      NOTES: 'Notes'
    },

    SALES_EG: {
      ORDER_ID: 'Order ID',
      ORDER_DATE: 'Order Date',
      PLATFORM: 'Platform',
      CUSTOMER_NAME: 'Customer Name',
      PHONE: 'Phone',
      CITY: 'City',
      ADDRESS: 'Address',
      SKU: 'SKU',
      PRODUCT_NAME: 'Product Name',
      VARIANT: 'Variant / Color',
      WAREHOUSE: 'Warehouse (EG)',
      QTY: 'Qty',
      UNIT_PRICE: 'Unit Price (EGP)',
      TOTAL_PRICE: 'Total Price (EGP)',
      DISCOUNT: 'Discount (EGP)',
      NET_REVENUE: 'Net Revenue (EGP)',
      SHIPPING_FEE: 'Shipping Fee (EGP)',
      PAYMENT_METHOD: 'Payment Method',
      ORDER_STATUS: 'Order Status',
      DELIVERED_DATE: 'Delivered Date',
      NOTES: 'Notes',
      SOURCE: 'Source',
      COURIER: 'Courier',
      AWB: 'AWB'
    }
  },

  /**
   * Header aliasing for migration (optional repair).
   * IMPORTANT: Keep aliases SAFE across sheets (do not add generic names like "Payment Method" here).
   */
  HEADER_ALIASES: {
    'Product': 'Product Name',
    'ProductName': 'Product Name',
    'Variant/Color': 'Variant / Color',
    'Variant': 'Variant / Color',

    // Dash variants / legacy headers
    'Ship Cost (EGP) - per unit or box': 'Ship Cost (EGP) – per unit or box',
    'Ship Cost (EGP) — per unit or box': 'Ship Cost (EGP) – per unit or box',
    'Ship Cost (EGP) — per unit': 'Ship Cost (EGP) – per unit',
    'Qty (pcs)': 'Qty',
    // Arabic common variants (status)
    'تم التسليم': 'Delivered',
    'تم التوصيل': 'Delivered',
    'تم التسليم للعميل': 'Delivered'
  },

  SETTINGS_KEYS: {
    DEFAULT_CURRENCY: 'Default Currency',
    FX_CNY_EGP: 'FX CNY→EGP',
    FX_AED_EGP: 'Default FX AED→EGP',
    SHIP_UAE_EG_ORDER: 'Default Ship UAE→EG (EGP) / order',
    CUSTOMS_PCT: 'Default Customs % (e.g. 0.20 = 20%)'
  },

  SETTINGS_LIST_HEADERS: {
    PLATFORMS: 'Platforms',
    PAYMENT_METHODS: 'Payment Methods',
    CURRENCIES: 'Currencies',
    STORES: 'Stores (optional)',
    WAREHOUSES: 'Warehouses'
  },

  INTERNAL: {
    SETTINGS_CACHE_KEY: 'CocoERP_SettingsMap_v1',
    USE_INSTALLABLE_ONEDIT_PROP: 'CocoERP_UseInstallableOnEdit',

    // Orders sync queue (Purchases → Orders)
    ORDERS_SYNC_QUEUE_KEY: 'CocoERP_OrdersSyncQueue_v1',
    ORDERS_SYNC_ALL_FLAG: 'CocoERP_OrdersSyncAllFlag_v1',
    ORDERS_SYNC_LAST_RUN: 'CocoERP_OrdersSyncLastRun_v1',
    ORDERS_SYNC_LAST_ERROR: 'CocoERP_OrdersSyncLastError_v1',

    // QC generation queue (Purchases → QC_UAE)
    QC_GEN_QUEUE_KEY: 'CocoERP_QcGenQueue_v1',
    QC_GEN_ALL_FLAG: 'CocoERP_QcGenAllFlag_v1',
    QC_GEN_LAST_RUN: 'CocoERP_QcGenLastRun_v1',
    QC_GEN_LAST_ERROR: 'CocoERP_QcGenLastError_v1',

    // Shipments CN→UAE sync flag (Purchases → Shipments_CN_UAE)
    SHIP_CN_UAE_SYNC_FLAG: 'CocoERP_ShipCnUaeSyncFlag_v1',
    SHIP_CN_UAE_LAST_RUN: 'CocoERP_ShipCnUaeLastRun_v1',
    SHIP_CN_UAE_LAST_ERROR: 'CocoERP_ShipCnUaeLastError_v1',

    // QC → Inventory sync flag
    QC_INV_SYNC_FLAG: 'CocoERP_QcInvSyncFlag_v1',
    QC_INV_LAST_RUN: 'CocoERP_QcInvLastRun_v1',
    QC_INV_LAST_ERROR: 'CocoERP_QcInvLastError_v1',

    // Shipments UAE→EG → Inventory sync flag
    SHIP_UAE_EG_INV_SYNC_FLAG: 'CocoERP_ShipUaeEgInvSyncFlag_v1',
    SHIP_UAE_EG_INV_LAST_RUN: 'CocoERP_ShipUaeEgInvLastRun_v1',
    SHIP_UAE_EG_INV_LAST_ERROR: 'CocoERP_ShipUaeEgInvLastError_v1'

  }
};

/** ===================== CORE HELPERS ===================== */

function getSpreadsheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (ss) return ss;

  const id = (APP.BASE && APP.BASE.SPREADSHEET_ID) ? String(APP.BASE.SPREADSHEET_ID).trim() : '';
  if (id) return SpreadsheetApp.openById(id);

  throw new Error('No active spreadsheet and APP.BASE.SPREADSHEET_ID is empty/invalid.');
}

function getSheet_(name) {
  const ss = getSpreadsheet_();
  const sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Sheet "' + name + '" not found.');
  return sh;
}

function ensureSheet_(name) {
  const ss = getSpreadsheet_();
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  return sh;
}

function getHeaderMap_(sheet, headerRow) {
  const row = headerRow || 1;
  const lastCol = sheet.getLastColumn();
  if (lastCol === 0) return {};
  const headers = sheet.getRange(row, 1, 1, lastCol).getValues()[0];
  const map = {};
  headers.forEach(function (h, i) {
    const key = (h || '').toString().trim();
    if (key) map[key] = i + 1;
  });
  return map;
}

function colLetter_(colIndex) {
  let index = colIndex;
  let s = '';
  while (index > 0) {
    const mod = (index - 1) % 26;
    s = String.fromCharCode(65 + mod) + s;
    index = Math.floor((index - mod) / 26);
  }
  return s;
}

function resolveCol_(headerMap, candidates) {
  for (let i = 0; i < candidates.length; i++) {
    const k = candidates[i];
    if (headerMap[k]) return headerMap[k];
  }
  return 0;
}

function assertRequiredColumns_(sheet, requiredCols) {
  const map = getHeaderMap_(sheet);
  const missing = requiredCols.filter(function (c) { return !map[c]; });
  if (missing.length) {
    throw new Error('Missing columns in "' + sheet.getName() + '": ' + missing.join(', '));
  }
  return map;
}

function ensureSheetSchema_(sheetName, headers, opts) {
  const options = opts || {};
  const headerRow = options.headerRow || 1;
  const addMissing = options.addMissing !== false;

  const sh = ensureSheet_(sheetName);
  const lastRow = sh.getLastRow();

  if (lastRow === 0) {
    sh.getRange(headerRow, 1, 1, headers.length).setValues([headers]);
    return sh;
  }

  const map = getHeaderMap_(sh, headerRow);
  if (!addMissing) return sh;

  const missing = headers.filter(function (h) { return !map[h]; });
  if (missing.length) {
    const startCol = sh.getLastColumn() + 1;
    sh.getRange(headerRow, startCol, 1, missing.length).setValues([missing]);
  }

  return sh;
}

function normalizeHeaders_(sh, headerRow) {

  // Normalize common punctuation differences (en/em dash -> hyphen)
  const _canon_ = (v) => String(v || '').replace(/[\u2013\u2014]/g, '-').trim();
  const row = headerRow || 1;
  const lastCol = sh.getLastColumn();
  if (lastCol === 0) return;

  const range = sh.getRange(row, 1, 1, lastCol);
  const headers = range.getValues()[0];

  let changed = false;
  for (let i = 0; i < headers.length; i++) {
    const raw = (headers[i] || '').toString().trim();
    const alias = APP.HEADER_ALIASES[raw];
    if (alias && alias !== raw) {
      headers[i] = alias;
      changed = true;
    }
  }

  if (changed) range.setValues([headers]);
}


function repairBlankHeadersByPosition_(sheetName, expectedHeaders, headerRow) {
  const row = headerRow || 1;
  if (!sheetName || !expectedHeaders || !expectedHeaders.length) return;

  const sh = ensureSheet_(sheetName);
  const lastCol = sh.getLastColumn();
  if (lastCol <= 0) return;

  const current = sh.getRange(row, 1, 1, lastCol).getValues()[0];
  const max = Math.min(current.length, expectedHeaders.length);

  let changed = false;
  for (let i = 0; i < max; i++) {
    const cur = String(current[i] || '').trim();
    if (cur) continue;

    const expected = expectedHeaders[i];
    if (!expected) continue;

    const exp = String(expected).trim();
    if (!exp) continue;

    current[i] = exp;
    changed = true;
  }

  if (changed) {
    sh.getRange(row, 1, 1, current.length).setValues([current]);
  }
}

/** ===================== ERROR LOGGING ===================== */

function ensureErrorLog_() {
  const sh = ensureSheet_(APP.SHEETS.ERROR_LOG);
  if (sh.getLastRow() === 0) {
    sh.appendRow(['Timestamp', 'Function', 'Message', 'Stack', 'Context']);
  }
  return sh;
}

function logError_(fnName, error, context) {
  try {
    const sh = ensureErrorLog_();
    const timestamp = Utilities.formatDate(new Date(), APP.BASE.TIMEZONE, 'yyyy-MM-dd HH:mm:ss');

    let ctxString = '';
    if (context) {
      try { ctxString = JSON.stringify(context); }
      catch (jsonErr) { ctxString = '<<context stringify failed: ' + (jsonErr && jsonErr.message) + '>>'; }
    }

    sh.appendRow([
      timestamp,
      fnName || '',
      (error && error.message) || String(error),
      (error && error.stack) || '',
      ctxString
    ]);
  } catch (e) {
    console.error('Failed to log error for ' + (fnName || '') + ': ' + (e && e.message ? e.message : e));
  }
}

/** ===================== LOCKING / SAFETY ===================== */

var __COCO_LOCK_DEPTH__ = 0;

/**
+ * Runs a function under a document lock.
+ *
+ * NOTE (important): LockService locks are NOT re-entrant. Because we sometimes compose
+ * locked functions (e.g., coco_processSyncQueue → locked stage functions), we treat
+ * nested calls within the same execution as re-entrant and reuse the already-held lock.
 */
function withLock_(lockName, fn) {
  const lock = LockService.getDocumentLock();

  // Re-entrant within the same execution (do NOT try to re-acquire the lock).
  if (__COCO_LOCK_DEPTH__ > 0) {
    __COCO_LOCK_DEPTH__++;
    try {
      return fn();
    } finally {
      __COCO_LOCK_DEPTH__--;
    }
  }

  const ok = lock.tryLock(25 * 1000);
  if (!ok) throw new Error('Could not acquire lock: ' + (lockName || 'DocumentLock'));

  __COCO_LOCK_DEPTH__ = 1;
  try {
    return fn();
  } finally {
    __COCO_LOCK_DEPTH__ = 0;
    try { lock.releaseLock(); } catch (e) { }
  }
}

/**
 * Normalize warehouse code:
 * - Trim + uppercase
 * - Convert whitespace/underscores to '-'
 * - Collapse multiple '-'
 */
function normalizeWarehouseCode_(wh) {
  if (!wh) return '';
  let s = String(wh).trim().toUpperCase();
  s = s.replace(/[_\s]+/g, '-');
  s = s.replace(/-+/g, '-').replace(/^-+|-+$/g, '');

  // Canonicalize legacy aliases (backward compatibility).
  // Canonical warehouses used by CocoERP v2.1:
  //  - UAE: KOR, ATTIA
  //  - EG : TAN-GH
  if (s === 'UAE' || s === 'UAE-DXB' || s === 'DUBAI') return 'KOR';
  if (s === 'UAE-KOR') return 'KOR';
  if (s === 'UAE-ATTIA') return 'ATTIA';

  return s;
}

/**
 * Delivered status detector (Arabic + English).
 * Used by Sales sync + other flows.
 */
function isDeliveredStatus_(status) {
  if (!status) return false;
  const s = String(status).trim().toLowerCase();
  if (!s) return false;

  // Exact matches
  if (s === 'delivered') return true;
  if (s === 'تم التسليم') return true;
  if (s === 'تم التسليم للعميل') return true;
  if (s === 'تم التوصيل') return true;

  // Loose contains
  if (s.includes('deliv')) return true;
  if (s.includes('تسليم')) return true;
  if (s.includes('توصيل')) return true;

  return false;
}

/* eslint-disable no-restricted-properties */
function tryGetUi_() {
  try {
    return SpreadsheetApp.getUi();
  } catch (_e) {
    return null;
  }
}
/* eslint-enable no-restricted-properties */

function safeAlert_(msg, title) {
  try {
    const ui = tryGetUi_();
    if (ui) {
      ui.alert(title ? String(title) : 'CocoERP', String(msg || ''));
    } else {
      Logger.log((title ? '[' + title + '] ' : '') + String(msg || ''));
    }
  } catch (e) {
    Logger.log('ALERT FAILED: ' + (e && e.message ? e.message : e));
  }
}

function safeConfirm_(title, msg) {
  const ui = tryGetUi_();
  if (!ui) {
    Logger.log('CONFIRM SKIPPED (no UI): ' + String(title || '') + ' :: ' + String(msg || ''));
    return false;
  }
  const res = ui.alert(String(title || 'Confirm'), String(msg || ''), ui.ButtonSet.YES_NO);
  return res === ui.Button.YES;
}

function safePromptText_(title, msg, defaultValue) {
  const ui = tryGetUi_();
  if (!ui) {
    Logger.log('PROMPT SKIPPED (no UI): ' + String(title || '') + ' :: ' + String(msg || ''));
    return null;
  }
  const res = ui.prompt(String(title || 'Input'), String(msg || ''), ui.ButtonSet.OK_CANCEL);
  if (res.getSelectedButton() !== ui.Button.OK) return null;
  const t = res.getResponseText();
  return t != null && String(t).trim() !== '' ? String(t).trim() : (defaultValue != null ? String(defaultValue) : '');
}


/**
 * Trigger-safe confirm dialog.
 * - In manual UI context: shows OK/CANCEL and returns true/false.
 * - In trigger/automation context: returns false.
 */
function safeConfirmYesNo_(title, message) {
  // Wrapper kept for backward compatibility.
  return safeConfirm_(title, message);
}

/**
 * Trigger-safe prompt.
 * - In manual UI context: returns trimmed text (may be empty string).
 * - If user cancels OR UI unavailable: returns null.
 */

/** ===================== SETTINGS LAYER ===================== */

function ensureSettingsSheet_() {
  const sh = ensureSheet_(APP.SHEETS.SETTINGS);

  // Always ensure header rows exist/correct (safe, idempotent).
  sh.getRange(1, 1, 1, 2).setValues([['Setting', 'Value']]);

  // Lists headers row (D1:...)
  sh.getRange(1, 4, 1, 5).setValues([[
    APP.SETTINGS_LIST_HEADERS.PLATFORMS,
    APP.SETTINGS_LIST_HEADERS.PAYMENT_METHODS,
    APP.SETTINGS_LIST_HEADERS.CURRENCIES,
    APP.SETTINGS_LIST_HEADERS.STORES,
    APP.SETTINGS_LIST_HEADERS.WAREHOUSES
  ]]);

  // Seed required Settings keys (non-destructive: fill only if missing)
  try {
    const map = getHeaderMap_(sh, 1);
    const keyCol = map['Setting'] || 1;
    const valCol = map['Value'] || 2;

    const lastRow = sh.getLastRow();
    const kv = (lastRow >= 2)
      ? sh.getRange(2, keyCol, lastRow - 1, 2).getValues()
      : [];

    const existing = {};
    kv.forEach(function (r) {
      const k = (r[0] || '').toString().trim();
      if (k) existing[k] = true;
    });

    const toAppend = [];
    function addIfMissing_(k, v) {
      if (!k) return;
      if (!existing[k]) {
        toAppend.push([k, v]);
        existing[k] = true;
      }
    }

    addIfMissing_(APP.SETTINGS_KEYS.DEFAULT_CURRENCY, 'AED');
    addIfMissing_(APP.SETTINGS_KEYS.FX_AED_EGP, 0);
    // Optional: keep for future if you ever capture USD rows; safe even if unused.
    if (APP.SETTINGS_KEYS.FX_USD_EGP) addIfMissing_(APP.SETTINGS_KEYS.FX_USD_EGP, 0);
    addIfMissing_(APP.SETTINGS_KEYS.SHIP_UAE_EG_ORDER, 0);
    addIfMissing_(APP.SETTINGS_KEYS.CUSTOMS_PCT, 0.20);

    if (toAppend.length) {
      sh.getRange(sh.getLastRow() + 1, keyCol, toAppend.length, 2).setValues(toAppend);
    }
  } catch (e) {
    // ignore - settings sheet is still usable
  }

  // Seed Warehouses list (D lists area) – non-destructive, allow future additions.
  try {
    const listMap = getHeaderMap_(sh, 1);
    const whCol = listMap[APP.SETTINGS_LIST_HEADERS.WAREHOUSES];
    if (whCol) {
      const desired = ['KOR', 'ATTIA', 'TAN-GH', '']; // last blank row as "future slot"
      const last = sh.getLastRow();
      const existingVals = (last >= 2)
        ? sh.getRange(2, whCol, last - 1, 1).getValues().map(function (r) { return (r[0] || '').toString().trim(); })
        : [];
      const hasAny = existingVals.some(function (v) { return v; });
      if (!hasAny) {
        sh.getRange(2, whCol, desired.length, 1).setValues(desired.map(function (v) { return [v]; }));
      }
    }
  } catch (e) { }

  return sh;
}

function clearSettingsCache_() {
  try {
    CacheService.getDocumentCache().remove('CocoERP_SettingsMap_v1');
  } catch (e) { }
}

function getSettingsMap_() {
  const cache = CacheService.getDocumentCache();
  const cacheKey = APP.INTERNAL.SETTINGS_CACHE_KEY;

  const cached = cache.get(cacheKey);
  if (cached) {
    try { return JSON.parse(cached); } catch (e) { }
  }

  const sh = ensureSettingsSheet_();
  const lastRow = sh.getLastRow();
  const map = {};

  if (lastRow >= 2) {
    const values = sh.getRange(2, 1, lastRow - 1, 2).getValues();
    values.forEach(function (r) {
      const k = (r[0] || '').toString().trim();
      if (!k) return;
      map[k] = r[1];
    });
  }

  cache.put(cacheKey, JSON.stringify(map), 60); // 60s cache
  return map;
}

function getSetting_(key, defaultValue) {
  const map = getSettingsMap_();
  const v = map[key];
  return (v === undefined || v === null || v === '') ? defaultValue : v;
}

function getDefaultFxAedEgp_() {
  const v = getSetting_(APP.SETTINGS_KEYS.FX_AED_EGP, 0);
  const n = Number(v);
  return isFinite(n) ? n : 0;
}

function getDefaultCurrency_() {
  // Settings sheet first; fallback to CNY
  const v = getSetting_(APP.SETTINGS_KEYS.DEFAULT_CURRENCY, 'CNY');
  return String(v || 'CNY').trim().toUpperCase();
}

function getDefaultFxRate_() {
  // Settings sheet first; return null if not configured
  const v = getSetting_(APP.SETTINGS_KEYS.FX_CNY_EGP, null);
  const n = Number(v);
  if (!isFinite(n) || n <= 0) return null;
  return n;
}

function getDefaultShipUaeEgPerOrder_() {
  const v = getSetting_(APP.SETTINGS_KEYS.SHIP_UAE_EG_ORDER, 0);
  const n = Number(v);
  return isFinite(n) ? n : 0;
}

function getDefaultCustomsPct_() {
  const v = getSetting_(APP.SETTINGS_KEYS.CUSTOMS_PCT, 0);
  const n = Number(v);
  return isFinite(n) ? n : 0;
}

function getSettingsListByHeader_(headerName) {
  const sh = ensureSettingsSheet_();
  const map = getHeaderMap_(sh, 1);
  const col = map[headerName];
  if (!col) return [];

  const lastRow = sh.getLastRow();
  if (lastRow < 2) return [];

  const raw = sh.getRange(2, col, lastRow - 1, 1).getValues();
  const vals = raw.map(function (r) { return (r[0] || '').toString().trim(); })
    .filter(function (v) { return v; });

  // unique
  const seen = {};
  const out = [];
  vals.forEach(function (v) {
    if (!seen[v]) { seen[v] = true; out.push(v); }
  });
  return out;
}

/** ===================== INVENTORY TXN HEADER ===================== */

function ensureInventoryTxnHeader_() {
  const sh = ensureSheet_(APP.SHEETS.INVENTORY_TXNS);
  const lastRow = sh.getLastRow();

  if (lastRow === 0) {
    let headers;
    if (typeof INV_TXN_HEADERS !== 'undefined' && INV_TXN_HEADERS && INV_TXN_HEADERS.length) {
      headers = INV_TXN_HEADERS;
    } else {
      headers = Object.keys(APP.COLS.INV_TXNS).map(function (k) { return APP.COLS.INV_TXNS[k]; });
    }
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  }
  return sh;
}

function clearInventoryTransactions_() {
  const sh = ensureSheet_(APP.SHEETS.INVENTORY_TXNS);
  const lastRow = sh.getLastRow();
  if (lastRow > 1) {
    sh.getRange(2, 1, lastRow - 1, sh.getLastColumn()).clearContent();
  }
}

/** ===================== SYSTEM ORCHESTRATION ===================== */

function inv_fullRebuildFromLogistics() {
  return withLock_('inv_fullRebuildFromLogistics', function () {
    try {
      clearInventoryTransactions_();
      ensureInventoryTxnHeader_();
      Logger.log('Inventory Transactions cleared and header ensured.');

      if (typeof syncQCtoInventory_UAE !== 'function') throw new Error('syncQCtoInventory_UAE function not found.');
      if (typeof syncShipmentsUaeEgToInventory !== 'function') throw new Error('syncShipmentsUaeEgToInventory function not found.');
      if (typeof inv_rebuildAllSnapshots !== 'function') throw new Error('inv_rebuildAllSnapshots function not found.');

      syncQCtoInventory_UAE();
      syncShipmentsUaeEgToInventory();
      inv_rebuildAllSnapshots();

      safeAlert_('✅ Full Rebuild Done Successfully!');
    } catch (err) {
      logError_('inv_fullRebuildFromLogistics', err);
      safeAlert_('❌ Error during rebuild: ' + err.message);
      throw err;
    }
  });
}

function coco_preflightAndRepair() {
  return withLock_('coco_preflightAndRepair', function () {
    try {
      ensureErrorLog_();
      ensureSettingsSheet_();

      // Ensure sheets exist (create if missing)
      Object.keys(APP.SHEETS).forEach(function (k) {
        ensureSheet_(APP.SHEETS[k]);
      });

      // If sheets were DELETED, bootstrap layouts to restore headers.
      _coco_bootstrapLayoutsIfMissingHeaders_();

      // Normalize headers (safe) — exclude Settings (handled separately).
      Object.keys(APP.SHEETS).forEach(function (k) {
        const shName = APP.SHEETS[k];
        const sh = ensureSheet_(shName);
        if (shName !== APP.SHEETS.SETTINGS) normalizeHeaders_(sh, 1);
      });


      // Repair known blank header issues by expected positions (non-destructive)
      try {
        if (typeof SHIP_UAE_EG_HEADERS !== 'undefined') {
          repairBlankHeadersByPosition_(APP.SHEETS.SHIP_UAE_EG, SHIP_UAE_EG_HEADERS, 1);
        }
        if (typeof SHIP_CN_UAE_HEADERS !== 'undefined') {
          repairBlankHeadersByPosition_(APP.SHEETS.SHIP_CN_UAE, SHIP_CN_UAE_HEADERS, 1);
        }
      } catch (e) {
        logError_('coco_preflightAndRepair.repairBlankHeaders', e);
      }

      // Ensure schemas we strongly expect (post-bootstrap)
      ensureSheetSchema_(APP.SHEETS.INVENTORY_TXNS, Object.keys(APP.COLS.INV_TXNS).map(function (k) { return APP.COLS.INV_TXNS[k]; }), { addMissing: true });
      ensureInventoryTxnHeader_();

      ensureSheetSchema_(APP.SHEETS.INVENTORY_UAE, Object.keys(APP.COLS.INV_UAE).map(function (k) { return APP.COLS.INV_UAE[k]; }), { addMissing: true });
      ensureSheetSchema_(APP.SHEETS.INVENTORY_EG, Object.keys(APP.COLS.INV_EG).map(function (k) { return APP.COLS.INV_EG[k]; }), { addMissing: true });

      ensureSheetSchema_(APP.SHEETS.CATALOG_EG, Object.keys(APP.COLS.CATALOG_EG).map(function (k) { return APP.COLS.CATALOG_EG[k]; }), { addMissing: true });
      ensureSheetSchema_(APP.SHEETS.SALES_EG, Object.keys(APP.COLS.SALES_EG).map(function (k) { return APP.COLS.SALES_EG[k]; }), { addMissing: true });

      safeAlert_('✅ Preflight + Repair completed.');
    } catch (err) {
      logError_('coco_preflightAndRepair', err);
      safeAlert_('❌ Preflight failed: ' + err.message);
      throw err;
    }
  });
}

/**
 * Bootstrap layouts after the user DELETES sheets.
 * This restores headers + formats by calling module setup functions when available.
 * Idempotent: only runs a setup if the target sheet has no header row content.
 */
function _coco_bootstrapLayoutsIfMissingHeaders_() {
  // Purchases & Orders
  if (_sheetHeaderEmpty_(APP.SHEETS.PURCHASES) && typeof setupPurchasesLayout === 'function') setupPurchasesLayout();
  if (_sheetHeaderEmpty_(APP.SHEETS.PURCHASES) && typeof installPurchasesFormulas === 'function') installPurchasesFormulas();
  if (_sheetHeaderEmpty_(APP.SHEETS.ORDERS) && typeof setupOrdersLayout === 'function') setupOrdersLayout();

  // Logistics / QC / Shipments
  // Prefer the unified layout installer if available.
  if ((_sheetHeaderEmpty_(APP.SHEETS.QC_UAE) || _sheetHeaderEmpty_(APP.SHEETS.SHIP_CN_UAE) || _sheetHeaderEmpty_(APP.SHEETS.SHIP_UAE_EG)) &&
    typeof setupLogisticsLayout === 'function') {
    setupLogisticsLayout();
  } else {
    if (_sheetHeaderEmpty_(APP.SHEETS.QC_UAE) && typeof setupQcLayout === 'function') setupQcLayout();
    if ((_sheetHeaderEmpty_(APP.SHEETS.SHIP_CN_UAE) || _sheetHeaderEmpty_(APP.SHEETS.SHIP_UAE_EG)) &&
      typeof setupShipmentsLayouts === 'function') setupShipmentsLayouts();
  }

  // Inventory core
  if ((_sheetHeaderEmpty_(APP.SHEETS.INVENTORY_TXNS) || _sheetHeaderEmpty_(APP.SHEETS.INVENTORY_UAE) || _sheetHeaderEmpty_(APP.SHEETS.INVENTORY_EG)) &&
    typeof setupInventoryCoreLayout === 'function') setupInventoryCoreLayout();

  // Catalog & Sales
  if (_sheetHeaderEmpty_(APP.SHEETS.CATALOG_EG) && typeof setupCatalogEgLayout === 'function') setupCatalogEgLayout();
  if (_sheetHeaderEmpty_(APP.SHEETS.SALES_EG) && typeof setupSalesLayout === 'function') setupSalesLayout();
}

function _sheetHeaderEmpty_(sheetName, headerRow) {
  const sh = ensureSheet_(sheetName);
  const row = headerRow || 1;
  const lastCol = sh.getLastColumn();
  if (lastCol === 0) return true;
  const vals = sh.getRange(row, 1, 1, lastCol).getValues()[0];
  for (let i = 0; i < vals.length; i++) {
    if (String(vals[i] || '').trim()) return false;
  }
  return true;
}

/** ===================== UI MENU ===================== */

function onOpen(e) {
  const ui = SpreadsheetApp.getUi();

  const mainMenu = ui.createMenu('CocoERP')
    .addSubMenu(
      ui.createMenu('System')
        .addItem('Preflight + Repair (Schemas/Headers)', 'coco_preflightAndRepair')
        .addSeparator()
        .addItem('Install Triggers (Recommended)', 'coco_installTriggers')
        .addItem('Uninstall Triggers', 'coco_uninstallTriggers')
        .addSeparator()
        .addItem('Run Core Tests', 'runCoreTests')
    )
    .addSubMenu(
      ui.createMenu('Purchases & Orders')
        .addItem('Setup Purchases Layout', 'setupPurchasesLayout')
        .addItem('Install Purchases Formulas', 'installPurchasesFormulas')
        .addSeparator()
        .addItem('Setup Orders Layout', 'setupOrdersLayout')
        .addItem('Setup Orders Layout (HARD RESET)', 'setupOrdersLayoutHardReset')
        .addItem('Rebuild Orders Summary', 'rebuildOrdersSummary')
        .addItem('Process Sync Queue Now', 'coco_processSyncQueueNow')
        .addItem('Debug Orders Sync Status', 'coco_debugOrdersSyncStatus')
    )
    .addSubMenu(
      ui.createMenu('Logistics & QC')
        .addItem('Setup QC Layout', 'setupQcLayout')
        .addItem('Setup Shipments Layouts', 'setupShipmentsLayouts')
        .addSeparator()
        .addItem('Generate QC from Purchases…', 'qc_generateFromPurchasesPrompt')
        .addItem('Recalc QC Quantities & Result', 'qc_recalcQuantitiesAndResult')
        .addItem('Backfill Purchases SKU', 'sku_backfillPurchasesSku')
    )
    .addSubMenu(
      ui.createMenu('Inventory')
        .addItem('Setup Inventory Core Layout', 'setupInventoryCoreLayout')
        .addItem('Rebuild Inventory Snapshots', 'inv_rebuildAllSnapshots')
        .addSeparator()
        .addItem('Sync QC → Inventory (UAE)', 'syncQCtoInventory_UAE')
        .addItem('Sync Shipments UAE→EG', 'syncShipmentsUaeEgToInventory')
        .addSeparator()
        .addItem('Full Rebuild from Logistics', 'inv_fullRebuildFromLogistics')
    );

  if (typeof setupSalesLayout === 'function' ||
    typeof syncSalesFromOrdersSheet === 'function' ||
    typeof syncSalesEgToInventory === 'function') {

    const salesMenu = ui.createMenu('Sales & Revenue');

    if (typeof setupSalesLayout === 'function') {
      salesMenu.addItem('Setup Sales Layout', 'setupSalesLayout');
    }
    if (typeof syncSalesFromOrdersSheet === 'function') {
      salesMenu.addItem('Sync from Orders sheet', 'syncSalesFromOrdersSheet');
    }
    if (typeof syncSalesEgToInventory === 'function') {
      salesMenu.addItem('Sync Sales → Inventory (EG)', 'syncSalesEgToInventory');
    }

    mainMenu.addSubMenu(salesMenu);
  }

  mainMenu.addToUi();
}

/** ===================== onEdit DISPATCHER ===================== */

function _useInstallableOnEditFlag_() {
  try {
    const p = PropertiesService.getDocumentProperties().getProperty(APP.INTERNAL.USE_INSTALLABLE_ONEDIT_PROP);
    return String(p || '') === '1';
  } catch (e) {
    return false;
  }
}

function _setUseInstallableOnEditFlag_(enabled) {
  const props = PropertiesService.getDocumentProperties();
  if (enabled) props.setProperty(APP.INTERNAL.USE_INSTALLABLE_ONEDIT_PROP, '1');
  else props.deleteProperty(APP.INTERNAL.USE_INSTALLABLE_ONEDIT_PROP);
}

function _dispatchOnEdit_(e) {
  if (!e || !e.range) return;

  const sheet = e.range.getSheet();
  const name = sheet.getName();

  // Settings edits -> invalidate cache only (A/B area).
  // We keep this light to avoid expensive recalcs on every Settings tweak.
  if (name === APP.SHEETS.SETTINGS) {
    const col = e.range.getColumn();
    if (col === 1 || col === 2) clearSettingsCache_();
    return;
  }

  // Purchases: fast defaults + SKU + enqueue Orders sync (debounced).
  // IMPORTANT: Do not early-return after SKU only, otherwise FX/Ship/Customs & Orders sync will stop.
  if (name === APP.SHEETS.PURCHASES) {
    try { if (typeof purchasesOnEditDefaults_ === 'function') purchasesOnEditDefaults_(e); } catch (err) {
      logError_('purchasesOnEditDefaults_', err, { sheet: name, a1: e && e.range && e.range.getA1Notation() });
    }
    try { if (typeof purchasesOnEditSku_ === 'function') purchasesOnEditSku_(e); } catch (err) {
      logError_('purchasesOnEditSku_', err, { sheet: name, a1: e && e.range && e.range.getA1Notation() });
    }

    // Enqueue incremental sync tasks (time-trigger processes within ~1 minute)
    try { coco_enqueueOrdersSyncFromPurchasesEdit_(e); } catch (err) { logError_('coco_enqueueOrdersSyncFromPurchasesEdit_', err, { sheet: name, a1: e && e.range && e.range.getA1Notation() }); }
    try { coco_enqueueQcGenFromPurchasesEdit_(e); } catch (err) { logError_('coco_enqueueQcGenFromPurchasesEdit_', err, { sheet: name, a1: e && e.range && e.range.getA1Notation() }); }
    try { coco_flagShipmentsCnUaeSyncFromPurchasesEdit_(e); } catch (err) { logError_('coco_flagShipmentsCnUaeSyncFromPurchasesEdit_', err, { sheet: name, a1: e && e.range && e.range.getA1Notation() }); }
    return;
  }


  // QC_UAE: auto-calc Qty Missing / Qty OK + QC Result on edit (script-based; no ARRAYFORMULA).
  if (name === (APP.SHEETS.QC_UAE || 'QC_UAE')) {
    try { if (typeof qcOnEdit_ === 'function') qcOnEdit_(e); } catch (err) {
      logError_('qcOnEdit_', err, { sheet: name, a1: e && e.range && e.range.getA1Notation() });
    }
    try { coco_flagQcInventorySyncFromQcEdit_(e); } catch (err) { logError_('coco_flagQcInventorySyncFromQcEdit_', err); }

    return;
  }

  if (name === APP.SHEETS.SHIP_CN_UAE) {
    try { if (typeof shipmentsCnUaeOnEdit_ === 'function') shipmentsCnUaeOnEdit_(e); }
    catch (err) { logError_('shipmentsCnUaeOnEdit_', err, { sheet: name, a1: e && e.range && e.range.getA1Notation() }); }

    try { coco_enqueueQcGenFromShipmentsCnUaeEdit_(e); }
    catch (err) { logError_('coco_enqueueQcGenFromShipmentsCnUaeEdit_', err, { sheet: name, a1: e && e.range && e.range.getA1Notation() }); }

    return;
  }

  if (name === APP.SHEETS.SHIP_UAE_EG) {
    try {
      if (typeof shipmentsUaeEgOnEdit_ === 'function') shipmentsUaeEgOnEdit_(e);
    } catch (err) {
      logError_('shipmentsUaeEgOnEdit_', err, { sheet: name, a1: e.range.getA1Notation() });
    }

    // ✅ This is the missing piece: enqueue/flag inventory sync
    try {
      coco_flagShipUaeEgInventorySyncFromEdit_(e);
    } catch (err) {
      logError_('coco_flagShipUaeEgInventorySyncFromEdit_', err, { sheet: name, a1: e.range.getA1Notation() });
    }

    return;
  }


  if (name === APP.SHEETS.SALES_EG && typeof salesEgOnEdit_ === 'function') {
    salesEgOnEdit_(e);
    return;
  }
}

function coco_enqueueQcGenFromShipmentsCnUaeEdit_(e) {
  if (!e || !e.range) return;
  const sh = e.range.getSheet();
  if (sh.getName() !== APP.SHEETS.SHIP_CN_UAE) return;

  const map = getHeaderMap_(sh, 1);

  const cOrder = map[APP.COLS.SHIP_CN_UAE.ORDER_BATCH] || map['Order ID (Batch)'] || map['Order ID'];
  const cArrival = map[APP.COLS.SHIP_CN_UAE.ARRIVAL] || map['Actual Arrival'];
  const cStatus = map[APP.COLS.SHIP_CN_UAE.STATUS] || map['Status'];

  if (!cOrder) return;

  const nr = e.range.getNumRows();
  const nc = e.range.getNumColumns();
  const c1 = e.range.getColumn();
  const c2 = c1 + nc - 1;

  // Only react if edit touches Arrival/Status columns
  const relevant = [cArrival, cStatus].filter(Boolean);
  let hit = false;
  for (let i = 0; i < relevant.length; i++) {
    const c = relevant[i];
    if (c >= c1 && c <= c2) { hit = true; break; }
  }
  if (!hit) return;

  const startRow = Math.max(2, e.range.getRow());
  const endRow = Math.min(sh.getLastRow(), e.range.getRow() + nr - 1);
  const n = Math.max(0, endRow - startRow + 1);
  if (n <= 0) return;

  const orderVals = sh.getRange(startRow, cOrder, n, 1).getValues();
  const statusVals = cStatus ? sh.getRange(startRow, cStatus, n, 1).getValues() : null;
  const arrVals = cArrival ? sh.getRange(startRow, cArrival, n, 1).getValues() : null;

  const set = {};
  for (let i = 0; i < n; i++) {
    const oid = String(orderVals[i][0] || '').trim();
    if (!oid) continue;

    const status = statusVals ? String(statusVals[i][0] || '').trim() : '';
    const arrival = arrVals ? arrVals[i][0] : null;

    const isArrivedUAE = !!arrival || status === 'Arrived UAE';
    if (isArrivedUAE) set[oid] = true;
  }

  const ids = Object.keys(set);
  if (ids.length) coco_enqueueQcGen_(ids);
}

function onEdit(e) {
  try {
    // If installable trigger is enabled, avoid double-run:
    // - Simple trigger runs with LIMITED authMode.
    // - Installable runs with FULL.
    if (e && e.authMode === ScriptApp.AuthMode.LIMITED && _useInstallableOnEditFlag_()) return;

    _dispatchOnEdit_(e);
  } catch (err) {
    logError_('onEdit', err, {
      sheet: e && e.range && e.range.getSheet().getName(),
      a1: e && e.range && e.range.getA1Notation()
    });
  }
}


/** Installable onEdit handler (FULL auth) */
function coco_onEditInstallable(e) {
  try {
    _dispatchOnEdit_(e);
  } catch (err) {
    logError_('coco_onEditInstallable', err, {
      sheet: e && e.range && e.range.getSheet().getName(),
      a1: e && e.range && e.range.getA1Notation()
    });
  }
}

/** ===================== TRIGGERS (INSTALLABLE) ===================== */

function _coco_deleteTriggersNoLock_() {
  const triggers = ScriptApp.getProjectTriggers();
  triggers.forEach(function (t) {
    const fn = t.getHandlerFunction();
    // Delete legacy + current handlers safely
    if (fn === 'onEdit' || fn === 'onOpen' || fn === 'coco_onEditInstallable' || fn === 'coco_processSyncQueue') {
      ScriptApp.deleteTrigger(t);
    }
  });
}

function coco_installTriggers() {
  return withLock_('coco_installTriggers', function () {
    try {
      _coco_deleteTriggersNoLock_();

      // Cleanup legacy/broken queue keys (older builds stored under key 'undefined')
      try {
        const dp = PropertiesService.getDocumentProperties();
        dp.deleteProperty('undefined');
      } catch (e) { }

      const ss = getSpreadsheet_();

      // Installable onEdit (FULL auth)
      ScriptApp.newTrigger('coco_onEditInstallable').forSpreadsheet(ss).onEdit().create();
      _setUseInstallableOnEditFlag_(true);

      // Time-based queue processor (debounced Orders sync)
      ScriptApp.newTrigger('coco_processSyncQueue').timeBased().everyMinutes(1).create();

      safeAlert_('✅ Triggers installed:\n- coco_onEditInstallable (onEdit)\n- coco_processSyncQueue (every 1 min)');
    } catch (err) {
      logError_('coco_installTriggers', err);
      safeAlert_('❌ Trigger install failed: ' + err.message);
      throw err;
    }
  });
}

function coco_uninstallTriggers() {
  return withLock_('coco_uninstallTriggers', function () {
    try {
      _coco_deleteTriggersNoLock_();
      try {
        const dp = PropertiesService.getDocumentProperties();
        dp.deleteProperty('undefined');
      } catch (e) { }
      _setUseInstallableOnEditFlag_(false);
      safeAlert_('✅ Installable triggers removed.');
    } catch (err) {
      logError_('coco_uninstallTriggers', err);
      throw err;
    }
  });
}

/** ===================== TESTS ===================== */

function runCoreTests() {
  try {
    const purchases = ensureSheet_(APP.SHEETS.PURCHASES);
    Logger.log('Found Purchases sheet: ' + purchases.getName());

    const errSh = ensureErrorLog_();
    Logger.log('ErrorLog sheet: ' + errSh.getName());

    const fx = getDefaultFxAedEgp_();
    Logger.log('Default FX AED→EGP: ' + fx);

    safeAlert_('✅ Core tests passed.');
  } catch (err) {
    logError_('runCoreTests', err);
    safeAlert_('❌ Core tests failed: ' + err.message);
    throw err;
  }
}

/** ===================== DEEP FREEZE (CONFIG SAFETY) ===================== */

function deepFreeze_(obj) {
  if (!obj || typeof obj !== 'object' || Object.isFrozen(obj)) return obj;
  Object.getOwnPropertyNames(obj).forEach(function (p) {
    try { deepFreeze_(obj[p]); } catch (e) { }
  });
  return Object.freeze(obj);
}

deepFreeze_(APP);


/** ============================================================
 * Formatting Helpers (used by Logistics.gs layouts)
 * ============================================================ */
function _applyNumberFormatByHeaders_(sh, headerMap, headerNames, numberFormat) {
  if (!sh || !headerMap || !headerNames || !headerNames.length) return;
  const lastRow = sh.getLastRow();
  if (lastRow < 2) return;

  const ranges = [];
  for (const h of headerNames) {
    const col1 = headerMap[h];
    if (!col1) continue;
    const col = Number(col1);
    if (!col || col < 1) continue;
    ranges.push(sh.getRange(2, col, lastRow - 1, 1).getA1Notation());
  }
  if (!ranges.length) return;
  sh.getRangeList(ranges).setNumberFormat(numberFormat);
}

function _applyDateFormatByHeaders_(sh, headerMap, headerNames) {
  _applyNumberFormatByHeaders_(sh, headerMap, headerNames, 'yyyy-mm-dd');
}
function _applyIntFormatByHeaders_(sh, headerMap, headerNames) {
  _applyNumberFormatByHeaders_(sh, headerMap, headerNames, '0');
}
function _applyDecimalFormatByHeaders_(sh, headerMap, headerNames) {
  _applyNumberFormatByHeaders_(sh, headerMap, headerNames, '0.00');
}


function coco_enqueueOrdersSync_(orderIds, opts) {
  opts = opts || {};
  return withLock_('coco_enqueueOrdersSync_', function () {
    const dp = PropertiesService.getDocumentProperties();

    if (opts.forceAll) {
      dp.setProperty(APP.INTERNAL.ORDERS_SYNC_ALL_FLAG, '1');
      dp.deleteProperty(APP.INTERNAL.ORDERS_SYNC_QUEUE_KEY);
      return;
    }

    const ids = (orderIds || [])
      .map(function (x) { return String(x || '').trim(); })
      .filter(function (x) { return !!x; });

    if (!ids.length) return;

    let existing = [];
    try {
      const raw = dp.getProperty(APP.INTERNAL.ORDERS_SYNC_QUEUE_KEY);
      if (raw) existing = JSON.parse(raw) || [];
    } catch (e) {
      existing = [];
    }

    const set = {};
    existing.forEach(function (x) { set[String(x || '').trim()] = true; });
    ids.forEach(function (x) { set[x] = true; });

    const merged = Object.keys(set).filter(function (x) { return !!x; });

    // Safety cap (avoid oversized properties)
    const capped = (merged.length > 5000) ? merged.slice(0, 5000) : merged;

    dp.setProperty(APP.INTERNAL.ORDERS_SYNC_QUEUE_KEY, JSON.stringify(capped));
  });
}


function coco_enqueueOrdersSyncFromPurchasesEdit_(e) {
  if (!e || !e.range) return;

  const sh = e.range.getSheet();
  if (sh.getName() !== APP.SHEETS.PURCHASES) return;

  const nr = e.range.getNumRows();
  const nc = e.range.getNumColumns();

  // Huge paste -> full rebuild (safer than trying to deduce IDs)
  if (nr > 300 || nc > 25) {
    coco_enqueueOrdersSync_(null, { forceAll: true });
    return;
  }

  const map = getHeaderMap_(sh, 1);
  const cOrder = map[APP.COLS.PURCHASES.ORDER_ID] || map['Order ID'];
  if (!cOrder) return;

  const startRow = Math.max(2, e.range.getRow());
  const endRow = Math.min(sh.getLastRow(), e.range.getRow() + nr - 1);
  const n = Math.max(0, endRow - startRow + 1);
  if (n <= 0) return;

  const vals = sh.getRange(startRow, cOrder, n, 1).getValues();
  const set = {};
  vals.forEach(function (r) {
    const oid = String(r[0] || '').trim();
    if (oid) set[oid] = true;
  });

  const ids = Object.keys(set);
  if (ids.length) coco_enqueueOrdersSync_(ids);
}

function coco_enqueueQcGen_(orderIds, opts) {
  opts = opts || {};
  return withLock_('coco_enqueueQcGen_', function () {
    const dp = PropertiesService.getDocumentProperties();

    if (opts.forceAll) {
      dp.setProperty(APP.INTERNAL.QC_GEN_ALL_FLAG, '1');
      dp.deleteProperty(APP.INTERNAL.QC_GEN_QUEUE_KEY);
      return;
    }

    const ids = (orderIds || [])
      .map(function (x) { return String(x || '').trim(); })
      .filter(function (x) { return !!x; });

    if (!ids.length) return;

    let existing = [];
    try {
      const raw = dp.getProperty(APP.INTERNAL.QC_GEN_QUEUE_KEY);
      if (raw) existing = JSON.parse(raw) || [];
    } catch (e) { existing = []; }

    const set = {};
    existing.forEach(function (x) { set[String(x || '').trim()] = true; });
    ids.forEach(function (x) { set[x] = true; });

    const merged = Object.keys(set).filter(Boolean);
    const capped = (merged.length > 5000) ? merged.slice(0, 5000) : merged;

    dp.setProperty(APP.INTERNAL.QC_GEN_QUEUE_KEY, JSON.stringify(capped));
  });
}

function coco_enqueueQcGenFromPurchasesEdit_(e) {
  if (!e || !e.range) return;
  const sh = e.range.getSheet();
  if (sh.getName() !== APP.SHEETS.PURCHASES) return;

  const nr = e.range.getNumRows();
  const nc = e.range.getNumColumns();

  // Huge paste -> full QC generation (safer than trying to deduce IDs)
  if (nr > 300 || nc > 25) {
    coco_enqueueQcGen_(null, { forceAll: true });
    return;
  }

  const map = getHeaderMap_(sh, 1);
  const cOrder = map[APP.COLS.PURCHASES.ORDER_ID] || map['Order ID'];
  const cSku = map[APP.COLS.PURCHASES.SKU] || map['SKU'];
  const cQty = map[APP.COLS.PURCHASES.QTY] || map['Qty'];
  const cLineId = map[APP.COLS.PURCHASES.LINE_ID] || map['Line ID'];
  const cProd = map[APP.COLS.PURCHASES.PRODUCT_NAME] || map['Product Name'];
  const cVar = map[APP.COLS.PURCHASES.VARIANT] || map['Variant / Color'];

  if (!cOrder) return;

  // Only enqueue if edit intersects relevant columns
  const c1 = e.range.getColumn();
  const c2 = c1 + nc - 1;
  const relevant = [cOrder, cSku, cQty, cLineId, cProd, cVar].filter(Boolean);
  let hit = false;
  for (let i = 0; i < relevant.length; i++) {
    const c = relevant[i];
    if (c >= c1 && c <= c2) { hit = true; break; }
  }
  if (!hit) return;

  const startRow = Math.max(2, e.range.getRow());
  const endRow = Math.min(sh.getLastRow(), e.range.getRow() + nr - 1);
  const n = Math.max(0, endRow - startRow + 1);
  if (n <= 0) return;

  const vals = sh.getRange(startRow, cOrder, n, 1).getValues();
  const set = {};
  vals.forEach(function (r) {
    const oid = String(r[0] || '').trim();
    if (oid) set[oid] = true;
  });

  const ids = Object.keys(set);
  if (ids.length) coco_enqueueQcGen_(ids);
}

function coco_flagShipmentsCnUaeSyncFromPurchasesEdit_(e) {
  if (!e || !e.range) return;
  const sh = e.range.getSheet();
  if (sh.getName() !== APP.SHEETS.PURCHASES) return;

  const nr = e.range.getNumRows();
  const nc = e.range.getNumColumns();

  const map = getHeaderMap_(sh, 1);
  const cOrder = map[APP.COLS.PURCHASES.ORDER_ID] || map['Order ID'];
  const cSku = map[APP.COLS.PURCHASES.SKU] || map['SKU'];
  const cQty = map[APP.COLS.PURCHASES.QTY] || map['Qty'];
  const cLineId = map[APP.COLS.PURCHASES.LINE_ID] || map['Line ID'];

  // If we can't resolve core cols, still allow a conservative flag on huge pastes
  const c1 = e.range.getColumn();
  const c2 = c1 + nc - 1;

  if (nr <= 300 && nc <= 25 && (cOrder || cSku || cQty || cLineId)) {
    const relevant = [cOrder, cSku, cQty, cLineId].filter(Boolean);
    let hit = false;
    for (let i = 0; i < relevant.length; i++) {
      const c = relevant[i];
      if (c >= c1 && c <= c2) { hit = true; break; }
    }
    if (!hit) return;
  }

  // Set a simple "needs sync" flag; processor will run full sync once
  return withLock_('coco_flagShipmentsCnUaeSyncFromPurchasesEdit_', function () {
    const dp = PropertiesService.getDocumentProperties();
    dp.setProperty(APP.INTERNAL.SHIP_CN_UAE_SYNC_FLAG, '1');
  });
}

function coco_flagQcInventorySyncFromQcEdit_(e) {
  try {
    if (!e || !e.range) return;
    const sh = e.range.getSheet();
    const map = getHeaderMap_(sh, 1);

    const c1 = e.range.getColumn();
    const c2 = c1 + (e.range.getNumColumns ? e.range.getNumColumns() : 1) - 1;

    const candidates = [
      APP.COLS.QC_UAE.QTY_RECEIVED,
      APP.COLS.QC_UAE.QTY_DEFECT,
      APP.COLS.QC_UAE.QTY_OK,
      APP.COLS.QC_UAE.QC_RESULT,
      APP.COLS.QC_UAE.WAREHOUSE,
    ];

    let hit = false;
    for (let i = 0; i < candidates.length; i++) {
      const col = map[candidates[i]];
      if (col && col >= c1 && col <= c2) { hit = true; break; }
    }
    if (!hit) return;

    PropertiesService.getDocumentProperties().setProperty(APP.INTERNAL.QC_INV_SYNC_FLAG, '1');
  } catch (err) {
    logError_('coco_flagQcInventorySyncFromQcEdit_', err);
  }
}

function coco_flagShipUaeEgInventorySyncFromEdit_(e) {
  try {
    if (!e || !e.range) return;
    const sh = e.range.getSheet();
    const map = getHeaderMap_(sh, 1);

    const c1 = e.range.getColumn();
    const c2 = c1 + (e.range.getNumColumns ? e.range.getNumColumns() : 1) - 1;

    const candidates = [
      APP.COLS.SHIP_UAE_EG.SHIPMENT_ID,
      APP.COLS.SHIP_UAE_EG.SKU,
      APP.COLS.SHIP_UAE_EG.QTY,
      APP.COLS.SHIP_UAE_EG.QTY_SYNCED,
      APP.COLS.SHIP_UAE_EG.SHIP_DATE,
      APP.COLS.SHIP_UAE_EG.ARRIVAL,
      APP.COLS.SHIP_UAE_EG.SHIP_COST,
      APP.COLS.SHIP_UAE_EG.CUSTOMS,
      APP.COLS.SHIP_UAE_EG.OTHER,
      APP.COLS.SHIP_UAE_EG.TOTAL_COST,
      'Warehouse (UAE)',
      'Courier',
    ];

    let hit = false;
    for (let i = 0; i < candidates.length; i++) {
      const col = map[candidates[i]];
      if (col && col >= c1 && col <= c2) { hit = true; break; }
    }
    if (!hit) return;

    PropertiesService.getDocumentProperties().setProperty(APP.INTERNAL.SHIP_UAE_EG_INV_SYNC_FLAG, '1');
  } catch (err) {
    logError_('coco_flagShipUaeEgInventorySyncFromEdit_', err);
  }
}

function coco_hasPendingShipUaeEgInventorySync_() {
  const sh = getSheet_(APP.SHEETS.SHIP_UAE_EG);
  const map = getHeaderMap_(sh);

  const cShipId = map[APP.COLS.SHIP_UAE_EG.SHIPMENT_ID] || map['Shipment ID'];
  const cSku = map[APP.COLS.SHIP_UAE_EG.SKU] || map['SKU'];
  const cQty = map[APP.COLS.SHIP_UAE_EG.QTY] || map['Qty'];
  const cSynced = map[APP.COLS.SHIP_UAE_EG.QTY_SYNCED] || map['Qty Synced'];

  if (!cShipId || !cSku || !cQty) return false;

  const lr = sh.getLastRow();
  if (lr < 2) return false;

  const vals = sh.getRange(2, 1, lr - 1, sh.getLastColumn()).getValues();

  const iShipId = cShipId - 1;
  const iSku = cSku - 1;
  const iQty = cQty - 1;
  const iSynced = cSynced ? (cSynced - 1) : -1;

  for (const r of vals) {
    const sid = String(r[iShipId] || '').trim();
    const sku = String(r[iSku] || '').trim();
    const qty = Number(r[iQty] || 0);
    const synced = iSynced >= 0 ? Number(r[iSynced] || 0) : 0;

    if (sid && sku && qty > synced) return true;
  }
  return false;
}

function coco_processSyncQueue() {
  return withLock_('coco_processSyncQueue', function () {
    const dp = PropertiesService.getDocumentProperties();

    const ordersForceAll = String(dp.getProperty(APP.INTERNAL.ORDERS_SYNC_ALL_FLAG) || '') === '1';
    const ordersRaw = dp.getProperty(APP.INTERNAL.ORDERS_SYNC_QUEUE_KEY);

    const qcForceAll = String(dp.getProperty(APP.INTERNAL.QC_GEN_ALL_FLAG) || '') === '1';
    const qcRaw = dp.getProperty(APP.INTERNAL.QC_GEN_QUEUE_KEY);

    const shipFlag = String(dp.getProperty(APP.INTERNAL.SHIP_CN_UAE_SYNC_FLAG) || '');

    const qcInvFlag0 = String(dp.getProperty(APP.INTERNAL.QC_INV_SYNC_FLAG) || '');
    const shipUaeEgInvFlag0 = String(dp.getProperty(APP.INTERNAL.SHIP_UAE_EG_INV_SYNC_FLAG) || '');

    // Auto-detect pending Shipments_UAE_EG deltas (Qty > Qty Synced) so queue works even without onEdit.
    let shipUaeEgInvFlag = shipUaeEgInvFlag0;
    if (shipUaeEgInvFlag !== '1') {
      try {
        if (coco_hasPendingShipUaeEgInventorySync_()) {
          dp.setProperty(APP.INTERNAL.SHIP_UAE_EG_INV_SYNC_FLAG, '1');
          shipUaeEgInvFlag = '1';
        }
      } catch (e) {
        logError_('coco_processSyncQueue:autoDetectShipUaeEg', e);
      }
    }

    // Early exit if nothing to do
    if (!ordersForceAll && !ordersRaw && !qcForceAll && !qcRaw && shipFlag !== '1' && qcInvFlag0 !== '1' && shipUaeEgInvFlag !== '1') return;

    const snapshot = {
      ordersForceAll: ordersForceAll ? '1' : '',
      ordersRaw: ordersRaw || '',
      qcForceAll: qcForceAll ? '1' : '',
      qcRaw: qcRaw || '',
      shipFlag: shipFlag || ''
    };

    // Clear early; restore on failure
    dp.deleteProperty(APP.INTERNAL.ORDERS_SYNC_ALL_FLAG);
    dp.deleteProperty(APP.INTERNAL.ORDERS_SYNC_QUEUE_KEY);
    dp.deleteProperty(APP.INTERNAL.QC_GEN_ALL_FLAG);
    dp.deleteProperty(APP.INTERNAL.QC_GEN_QUEUE_KEY);
    dp.deleteProperty(APP.INTERNAL.SHIP_CN_UAE_SYNC_FLAG);

    try { dp.deleteProperty(APP.INTERNAL.ORDERS_SYNC_LAST_ERROR); } catch (e) { }
    try { dp.deleteProperty(APP.INTERNAL.QC_GEN_LAST_ERROR); } catch (e) { }
    try { dp.deleteProperty(APP.INTERNAL.SHIP_CN_UAE_LAST_ERROR); } catch (e) { }

    let stage = 'init';

    try {
      // 1) Shipments CN→UAE sync (full, idempotent)
      stage = 'shipments';
      if (snapshot.shipFlag === '1') {
        if (typeof syncPurchasesToShipmentsCnUae === 'function') {
          syncPurchasesToShipmentsCnUae();
          try { dp.setProperty(APP.INTERNAL.SHIP_CN_UAE_LAST_RUN, new Date().toISOString()); } catch (e) { }
        } else {
          // Keep flag for retry and record error
          dp.setProperty(APP.INTERNAL.SHIP_CN_UAE_SYNC_FLAG, '1');
          dp.setProperty(APP.INTERNAL.SHIP_CN_UAE_LAST_ERROR, 'syncPurchasesToShipmentsCnUae is not defined.');
        }
      }

      // 2) QC generation (batch; requires qc_generateFromPurchases_ to support arrays)
      stage = 'qc';
      if (snapshot.qcForceAll === '1') {
        if (typeof qc_generateFromPurchases_ === 'function') {
          qc_generateFromPurchases_();
          try { dp.setProperty(APP.INTERNAL.QC_GEN_LAST_RUN, new Date().toISOString()); } catch (e) { }
          try { dp.setProperty(APP.INTERNAL.QC_INV_SYNC_FLAG, '1'); } catch (e) { }
        } else {
          dp.setProperty(APP.INTERNAL.QC_GEN_ALL_FLAG, '1');
          dp.setProperty(APP.INTERNAL.QC_GEN_LAST_ERROR, 'qc_generateFromPurchases_ is not defined.');
        }
      } else if (snapshot.qcRaw) {
        let ids = [];
        try { ids = JSON.parse(snapshot.qcRaw) || []; } catch (e) { ids = []; }
        ids = ids.map(function (x) { return String(x || '').trim(); }).filter(Boolean);

        if (ids.length) {
          // Runtime cap: do max 200 orderIds per minute
          const batch = (ids.length > 200) ? ids.slice(0, 200) : ids;
          const rest = (ids.length > batch.length) ? ids.slice(batch.length) : [];

          if (typeof qc_generateFromPurchases_ === 'function') {
            qc_generateFromPurchases_(batch);
            try { dp.setProperty(APP.INTERNAL.QC_GEN_LAST_RUN, new Date().toISOString()); } catch (e) { }
            try { dp.setProperty(APP.INTERNAL.QC_INV_SYNC_FLAG, '1'); } catch (e) { }
          } else {
            // restore queue for retry
            dp.setProperty(APP.INTERNAL.QC_GEN_QUEUE_KEY, snapshot.qcRaw);
            dp.setProperty(APP.INTERNAL.QC_GEN_LAST_ERROR, 'qc_generateFromPurchases_ is not defined.');
          }

          if (rest.length) dp.setProperty(APP.INTERNAL.QC_GEN_QUEUE_KEY, JSON.stringify(rest));
        }
      }

      const qcInvFlag = String(dp.getProperty(APP.INTERNAL.QC_INV_SYNC_FLAG) || '') === '1';
      const shipUaeEgInvFlag = String(dp.getProperty(APP.INTERNAL.SHIP_UAE_EG_INV_SYNC_FLAG) || '') === '1';

      // Clear flags early (debounce). If errors happen, we re-set them.
      if (qcInvFlag) dp.deleteProperty(APP.INTERNAL.QC_INV_SYNC_FLAG);
      if (shipUaeEgInvFlag) dp.deleteProperty(APP.INTERNAL.SHIP_UAE_EG_INV_SYNC_FLAG);

      if (qcInvFlag) {
        try {
          withLock_('QC_INV_SYNC', function () {
            if (typeof syncQCtoInventory_UAE !== 'function') throw new Error('syncQCtoInventory_UAE is not defined');
            syncQCtoInventory_UAE();
          });
          dp.setProperty(APP.INTERNAL.QC_INV_LAST_RUN, new Date().toISOString());
          dp.deleteProperty(APP.INTERNAL.QC_INV_LAST_ERROR);
        } catch (err) {
          dp.setProperty(APP.INTERNAL.QC_INV_SYNC_FLAG, '1'); // requeue
          dp.setProperty(APP.INTERNAL.QC_INV_LAST_ERROR, String(err && err.message ? err.message : err));
          logError_('coco_processSyncQueue:QC_INV', err);
        }
      }

      if (shipUaeEgInvFlag) {
        try {
          withLock_('SHIP_UAE_EG_INV_SYNC', function () {
            if (typeof syncShipmentsUaeEgToInventory !== 'function') throw new Error('syncShipmentsUaeEgToInventory is not defined');
            syncShipmentsUaeEgToInventory();
          });
          dp.setProperty(APP.INTERNAL.SHIP_UAE_EG_INV_LAST_RUN, new Date().toISOString());
          dp.deleteProperty(APP.INTERNAL.SHIP_UAE_EG_INV_LAST_ERROR);
        } catch (err) {
          dp.setProperty(APP.INTERNAL.SHIP_UAE_EG_INV_SYNC_FLAG, '1'); // requeue
          dp.setProperty(APP.INTERNAL.SHIP_UAE_EG_INV_LAST_ERROR, String(err && err.message ? err.message : err));
          logError_('coco_processSyncQueue:SHIP_UAE_EG_INV', err);
        }
      }

      // 3) Orders sync (existing behavior)
      stage = 'orders';
      const markOrdersSuccess_ = function () {
        try { dp.setProperty(APP.INTERNAL.ORDERS_SYNC_LAST_RUN, new Date().toISOString()); } catch (e) { }
      };

      if (snapshot.ordersForceAll === '1') {
        if (typeof rebuildOrdersSummary === 'function') {
          rebuildOrdersSummary();
        } else if (typeof orders_syncFromPurchasesByOrderIds_ === 'function') {
          orders_syncFromPurchasesByOrderIds_([]);
        }
        markOrdersSuccess_();
      } else if (snapshot.ordersRaw) {
        let ids = [];
        try { ids = JSON.parse(snapshot.ordersRaw) || []; } catch (e) { ids = []; }
        ids = ids.map(function (x) { return String(x || '').trim(); }).filter(Boolean);
        if (ids.length) {
          if (ids.length > 200 && typeof rebuildOrdersSummary === 'function') {
            rebuildOrdersSummary();
          } else if (typeof orders_syncFromPurchasesByOrderIds_ === 'function') {
            orders_syncFromPurchasesByOrderIds_(ids);
          } else if (typeof rebuildOrdersSummary === 'function') {
            rebuildOrdersSummary();
          }
          markOrdersSuccess_();
        }
      }
    } catch (err) {
      // Restore snapshot for retry
      if (snapshot.ordersForceAll === '1') dp.setProperty(APP.INTERNAL.ORDERS_SYNC_ALL_FLAG, '1');
      if (snapshot.ordersRaw) dp.setProperty(APP.INTERNAL.ORDERS_SYNC_QUEUE_KEY, snapshot.ordersRaw);

      if (snapshot.qcForceAll === '1') dp.setProperty(APP.INTERNAL.QC_GEN_ALL_FLAG, '1');
      if (snapshot.qcRaw) dp.setProperty(APP.INTERNAL.QC_GEN_QUEUE_KEY, snapshot.qcRaw);

      if (snapshot.shipFlag === '1') dp.setProperty(APP.INTERNAL.SHIP_CN_UAE_SYNC_FLAG, '1');

      try {
        const stack = String((err && err.stack) || err);
        if (stage === 'orders') dp.setProperty(APP.INTERNAL.ORDERS_SYNC_LAST_ERROR, stack);
        else if (stage === 'qc') dp.setProperty(APP.INTERNAL.QC_GEN_LAST_ERROR, stack);
        else if (stage === 'shipments') dp.setProperty(APP.INTERNAL.SHIP_CN_UAE_LAST_ERROR, stack);
      } catch (e) { }

      logError_('coco_processSyncQueue', err, { stage: stage });
      throw err;
    }
  });
}

function coco_processSyncQueueNow() {
  try {
    coco_processSyncQueue();
    safeAlert_('✅ Sync queue processed.');
  } catch (e) {
    logError_('coco_processSyncQueueNow', e);
    safeAlert_('❌ Sync queue failed: ' + e.message);
    throw e;
  }
}

/**
 * Debug helper: shows Orders sync queue status + availability of sync functions.
 */
function coco_debugOrdersSyncStatus() {
  try {
    const dp = PropertiesService.getDocumentProperties();
    const rawQueue = dp.getProperty(APP.INTERNAL.ORDERS_SYNC_QUEUE_KEY) || '[]';
    const forceAll = String(dp.getProperty(APP.INTERNAL.ORDERS_SYNC_ALL_FLAG) || '') === '1';
    const lastRun = dp.getProperty(APP.INTERNAL.ORDERS_SYNC_LAST_RUN) || '';
    const lastErr = dp.getProperty(APP.INTERNAL.ORDERS_SYNC_LAST_ERROR) || '';

    let queueLen = -1;
    try { queueLen = (JSON.parse(rawQueue) || []).length; } catch (e) { queueLen = -1; }

    const hasIncremental = (typeof orders_syncFromPurchasesByOrderIds_ === 'function');
    const hasRebuild = (typeof rebuildOrdersSummary === 'function');

    const msg = [
      'Orders Sync Status',
      '------------------',
      'forceAll: ' + forceAll,
      'queueLen: ' + queueLen,
      'queueRaw: ' + (rawQueue ? rawQueue.slice(0, 200) : '(empty)') + (rawQueue && rawQueue.length > 200 ? '...' : ''),
      '',
      'hasIncremental: ' + hasIncremental,
      'hasRebuild: ' + hasRebuild,
      '',
      'lastRun: ' + (lastRun || '(none)'),
      'lastError: ' + (lastErr ? lastErr.slice(0, 400) : '(none)')
    ].join('\n');

    safeAlert_(msg);
  } catch (e) {
    logError_('coco_debugOrdersSyncStatus', e);
    safeAlert_('Debug failed: ' + (e && e.message ? e.message : e));
  }
}

